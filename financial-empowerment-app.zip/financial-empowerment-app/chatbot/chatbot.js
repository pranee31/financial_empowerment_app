require('dotenv').config();
const axios = require('axios');
const readline = require('readline-sync');

const API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=" + API_KEY;

let chatHistory = []; // Store conversation history

async function chatWithGemini(userMessage) {
    try {
        // Add the user's new message to the history
        chatHistory.push({ role: "user", parts: [{ text: userMessage }] });

        // Limit history to the last 5 exchanges to avoid excessive data
        if (chatHistory.length > 10) {
            chatHistory = chatHistory.slice(-10);
        }

        const response = await axios.post(GEMINI_API_URL, {
            contents: chatHistory // Send full conversation history
        });

        const botMessage = response.data.candidates[0].content.parts[0].text;

        // Add bot response to chat history
        chatHistory.push({ role: "model", parts: [{ text: botMessage }] });

        return botMessage;
    } catch (error) {
        console.error("Error:", error.response ? error.response.data : error.message);
        return "Sorry, I couldn't process that request.";
    }
}



async function startChatbot() {
    console.log("💬 Finance Chatbot: Ask me anything about budgeting, saving, or finance terms!");
    
    while (true) {
        const userInput = readline.question("\nYou: ");
        if (userInput.toLowerCase() === "exit") {
            console.log("Goodbye! 👋");
            break;
        }

        const botResponse = await chatWithGemini(userInput);
        console.log("\n🤖 Gemini: " + botResponse);
    }
}

startChatbot();
